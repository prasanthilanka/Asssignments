rm(list=ls(all=T))
# Read the data
getwd()
setwd('C:\\Users\\sauragarwal\\Desktop\\Data Science training')
rawData <- read.csv("Patient Adherence - Data.csv", header=T)
rawData$PatientID <- as.factor(rawData$PatientID)
rawData$Date <- as.Date(rawData$Date)

# There is only one NA. Eyeballing the data shows that it has to be 205.
rawData[which(rawData$PatientID == "1015" & rawData$Medication == "Med423" & rawData$Pharmacy == "PHARMACY 1558"), ]$AmountPaid = 205

rawData$Age <- as.factor(floor(rawData$Age/10))

# Let's create lookup data just in case we need it later
Patients <- unique(rawData$PatientID)
Medications <- unique(rawData$Medication)
Pharmacies <- unique(rawData$Pharmacy)

# Observing the data of Patient.Med.Distribution shows us that none of the Patient-Medication combinations
#have more than 30 records. We will need at least 30 records for each independent variable to come up with 
#a reliable model. Therefore, it will not be appropriate to build a PatientID dependent model with the given data.

# This is a tricky data set since this is time based but has other variables too and hence cannot be 
# a time series. In order to be able to have a regression model to predict the next purchase behavior, 
# the current purchase data should have some variable that will signify the past purchase pattern.

# As of now, we have PurchaseLapseDays, Compliance factor(with a threshold of 7 lapse days)
# Lets create a new Lapse.Factor that should depend on the below parameters
# Purchase lapse days increase or decrease. To be represented by +/-. 
#Formula: (PurchaseLapseDays[k]-PurcahseLapseDays[k-1])^2/(PurchaseLapseDays[k]-PurcahseLapseDays[k-1])
# Share of Compliance so far. Formula: No.Of.Compliance.So.Far/Total.Purchases.So.Far
# Let's try to calculate the number of days between the purchases
result <- data.frame()
count <- 0
maxCount <- 8*46
for(threshold in 0:7){
  for(limit in 15:60){
    PurchaseBehavior <- data.frame()
    for (i in 1:length(Patients)){
      for (j in 1:length(Medications)){
        patientMedData <- rawData[which(rawData$PatientID == Patients[i]
                                        & rawData$Medication == Medications[j]), ]

        # Consider only those patient-med record for whom we have more than one record
        if (nrow(patientMedData) > 1){
          prevDate <- patientMedData[1, "Date"]
          PurchasedAfter <- vector(length=nrow(patientMedData))
          PurchaseLapseDays <- vector(length=nrow(patientMedData))
          Adherence <- rep(NA, nrow(patientMedData))
          subAdherence <- rep(NA, nrow(patientMedData))
          Lapse.Factor <- vector(length=nrow(patientMedData))
          Adherence.Level <- vector(length=nrow(patientMedData))
          Purchase.Round <- vector(length=nrow(patientMedData))
          Next.Lapse <- rep(NA, nrow(patientMedData))
          PurchaseLapseDays[1] <- 0
          Adherence[1] <- 1
          subAdherence[1] <- 1
          Lapse.Factor[1] <- 0
          Adherence.Level[1] <- 1
          Purchase.Round[1] <- 1
          for (k in 2:nrow(patientMedData)){
            PurchasedAfter[k] <- patientMedData[k, "Date"] - prevDate
            PurchaseLapseDays[k] <- PurchasedAfter[k] - patientMedData[k, "For_How_Many_Days"]
            # If the patient is buying the same medicine after 30 days, let's assume that this
            # is the next round of purchase
            if(PurchaseLapseDays[k] > limit){
              Purchase.Round[k] <- Purchase.Round[k-1]+1
              PurchaseLapseDays[k] <- 0
              Lapse.Factor[k] <- 0
              Next.Lapse[k-1] <- NA
              subAdherence <- rep(NA, nrow(patientMedData))
            } else{
              Purchase.Round[k] <- Purchase.Round[k-1]
              Lapse.Factor[k] <- PurchaseLapseDays[k]-PurchaseLapseDays[k-1]
              Next.Lapse[k-1] <- PurchaseLapseDays[k]
            }
            # Let's assume that a patient is adherant if the lapse days is within a week
            if (PurchaseLapseDays[k] > threshold){
              subAdherence[k] <- 0
            } else{
              subAdherence[k] <- 1
            }
            Adherence.Table <- as.data.frame(table(subAdherence))
            Adherence.Level[k] <- Adherence.Table[which(Adherence.Table$subAdherence==1), "Freq"]/sum(Adherence.Table$Freq)
            Adherence[k] <- subAdherence[k]
            prevDate <- patientMedData[k, "Date"]
          }

          PatientPurchaseBehavior <- cbind(patientMedData, PurchasedAfter, PurchaseLapseDays, Adherence, Lapse.Factor, Adherence.Level, Next.Lapse, Purchase.Round)
          PurchaseBehavior <- rbind(PurchaseBehavior, PatientPurchaseBehavior)
        }
      }
    }
    # Clean the slate, keep what is needed only
    rm(PatientPurchaseBehavior, patientMedData, i, j, k, PurchasedAfter, prevDate, Adherence, PurchaseLapseDays, Lapse.Factor, Adherence.Table, Adherence.Level, Next.Lapse, Purchase.Round, subAdherence)

    PurchaseBehavior$Adherence <- as.factor(PurchaseBehavior$Adherence)
    PurchaseBehavior$PurchaseLapseDays <- as.integer(PurchaseBehavior$PurchaseLapseDays)
    PurchaseBehavior$Lapse.Factor <- as.integer(PurchaseBehavior$Lapse.Factor)
    PurchaseBehavior$Next.Lapse <- as.integer(PurchaseBehavior$Next.Lapse)

    #Med.Count <- as.data.frame(table(PurchaseBehavior$Medication))
    #Outlier.Meds <- Med.Count[which(Med.Count$Freq == 0), ]

    #PurchaseBehaviorTrend <- PurchaseBehavior[-which(PurchaseBehavior$Medication %in% Outlier.Meds$Var1), ]
    PurchaseBehaviorTrend <- PurchaseBehavior

    PurchaseBehaviorTrend <- data.frame(PurchaseBehaviorTrend, Months=months(PurchaseBehaviorTrend$Date))

    # Let's keep only those columns that matter now
    AdherenceTrend <- PurchaseBehaviorTrend[ , c(2, 3, 4, 6, 7, 11, 13, 14, 15, 16, 17)]
    # At this stage, the AdherenceTrend data frame has in each row the past

    # Let's build some models now
    # Reference.Data for train and test should have all the possible medicines and pharmacies
    Reference.Data <- na.omit(AdherenceTrend)
    Reference.Data <- Reference.Data[-which(Reference.Data$Pharmacy=="PHARMACY 1558"),]
    Ref.Train.Data <- data.frame()
    Ref.Test.Data <- data.frame()
    for(i in 1:length(Medications)){
      for(j in 1:length(Pharmacies)){
        subData <- Reference.Data[which(Reference.Data$Medication==Medications[i] & Reference.Data$Pharmacy==Pharmacies[j]), ]
        if(nrow(subData)>1){
          rows <- 1:nrow(subData)
          set.seed(123)
          Train.Index <- sample(rows, floor(nrow(subData)*0.7))
          Test.Index <- rows[-Train.Index]
          Train.Data <- subData[Train.Index, ]
          Test.Data <- subData[Test.Index, ]

          Ref.Train.Data <- rbind(Ref.Train.Data, Train.Data)
          Ref.Test.Data <- rbind(Ref.Test.Data, Test.Data)
        }
      }
    }

    rm(i, j, rows, Train.Index, Test.Index, Train.Data, Test.Data, subData)

    LinReg_All<-lm(Next.Lapse~Medication + Age + Sex + Pharmacy +
                     AmountPaid + PurchaseLapseDays + Adherence + Lapse.Factor +
                     Adherence.Level, data=Ref.Train.Data)

    library(DMwR)
    #Evaluation on the train data with the model developed using all attributes
    trainMAE <- as.data.frame(regr.eval(Ref.Train.Data$Next.Lapse,LinReg_All$fitted.values))["mae",]


    #Predicting the PurchaseLapseDays in the test data using the model developed and evaluating the fit
    Prediction <- as.data.frame(predict(LinReg_All, Ref.Test.Data[,], interval='confidence'))
    testMAE <- as.data.frame(regr.eval(Ref.Test.Data$Next.Lapse, Prediction$fit))["mae", ]

    residue <- testMAE-trainMAE

    result <- rbind(result, data.frame(threshold, limit, trainMAE, testMAE, residue))

    cat(count, " of ", maxCount, "\n")
    count <- count+1
  }
}

#KNN Algo Implementation

# to prepare train & test data sets
train = sample(1:2578,1700) # to take a random sample of  ~ 60% of the records for train data 
patient_train = PurchaseBehaviorTrend[train,] 
nrow(patient_train)
test = (1:2578) [-train] # to take a random sample of  40% of the records for test data 
patient_test = PurchaseBehaviorTrend[test,] 
nrow(patient_test)

#install.packages("class")
library(class)
pred1=knn(patient_train[,-c(19)], patient_test[,-c(1,2,5,19)], patient_train$Adherence,k = 1)
table(pred1,patient_test$Adherence)

pred2=knn(patient_train[,-c(1,2,5,19)], patient_test[,-c(1,2,5,19)], patient_train$Adherence, 
         k = 3)
table(pred2,patient_test$Adherence)

pred3=knn(patient_train[,-c(1,2,5,19)], patient_test[,-c(1,2,5,19)], patient_train$Adherence, 
         k = 5)
table(pred3,patient_test$Adherence)

pred4=knn(patient_train[,-c(1,2,5,19)], patient_test[,-c(1,2,5,19)], patient_train$Adherence, 
         k = 7)
table(pred4,patient_test$Adherence)
